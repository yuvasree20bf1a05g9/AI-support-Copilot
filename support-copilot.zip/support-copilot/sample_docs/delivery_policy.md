# Delivery & Delivery Partner Policy

## Delivery Time Estimates

Estimated delivery times shown at checkout are calculated based on restaurant
prep time plus average delivery partner travel time for the area. During heavy
rain, festivals, or high-demand hours, actual delivery time may exceed the
estimate by 15-30 minutes; this is considered normal and should not automatically
trigger a refund.

## Delivery Partner Behavior Complaints

Complaints about delivery partner behavior (rudeness, refusal to deliver to door,
hygiene concerns) should be logged in the delivery partner's record. A single
complaint does not result in partner deactivation. Three or more verified
complaints within 90 days trigger an automatic review by the delivery operations
team.

## Contactless Delivery

Customers can request contactless delivery at checkout. If a delivery partner
fails to follow a contactless delivery request, the customer is eligible for a
goodwill credit of 50 rupees, not a full refund, unless combined with another
valid complaint (e.g., missing item).

## Order Not Received

If a customer reports an order as "not received" but the delivery partner's app
shows a completed delivery with photo/GPS confirmation, support should first ask
the customer to check with neighbors, building security, or family members before
processing any refund. If there is no delivery confirmation photo or GPS mismatch,
the claim should be treated as valid and processed for a full refund.

## Delivery Partner Ratings ("Karma")

Delivery partners are scored on a rolling performance metric based on on-time
delivery rate, customer ratings, and order acceptance rate. Partners who fall
below the minimum threshold for two consecutive weeks receive a performance
improvement notice before any account action is taken.
