# Refund Policy

## Order Cancellations

Customers can cancel an order for a full refund within 5 minutes of placing it,
as long as the restaurant has not started preparing the food. After 5 minutes,
cancellations are subject to restaurant confirmation, and a partial refund may
apply if preparation has already begun.

## Missing or Incorrect Items

If a customer receives an incomplete order or the wrong item, they are eligible
for a full refund on the missing/incorrect items, provided the issue is reported
within 24 hours of delivery. Refunds for missing items are processed automatically
if the order value of the missing item is under 300 rupees. Claims above 300 rupees
require a support agent to review delivery partner notes before approval.

## Food Quality Issues

Refunds for food quality complaints (spoiled, undercooked, foreign object found)
require the customer to submit at least one photo of the item. Quality-related
refunds are capped at one per customer per rolling 30-day window unless a support
lead approves an exception. Repeated quality claims from the same account without
photo evidence should be flagged for manual review rather than auto-refunded.

## Late Delivery Refunds

If a delivery arrives more than 45 minutes after the promised time, the customer
is eligible for a partial refund of the delivery fee. If the delay exceeds 90
minutes, the customer may request a full refund of the order instead of a partial
delivery-fee refund, but not both.

## Refund Processing Time

Approved refunds are credited to the original payment method within 5-7 business
days. Refunds to wallet balance are instant. Customers asking about refund status
before 7 business days should be told the standard timeline rather than escalated.

## Escalation Rule

Any refund request involving an order value above 2000 rupees, or any customer
who has submitted 3 or more refund requests in the past 30 days, must be escalated
to a senior support associate and should not be auto-approved by policy lookup alone.
