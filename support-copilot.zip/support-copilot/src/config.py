"""
Central configuration for the Support Copilot.
Keeping every tunable in one place makes the confidence threshold and
chunking strategy easy to explain and defend in an interview.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# --- Paths ---
BASE_DIR = Path(__file__).resolve().parent.parent
SAMPLE_DOCS_DIR = BASE_DIR / "sample_docs"
VECTOR_DB_DIR = BASE_DIR / "data" / "chroma_db"

# --- Chunking ---
# Overlap prevents a policy rule from being split across two chunks with no
# shared context, which would otherwise hurt retrieval accuracy.
CHUNK_SIZE = 500
CHUNK_OVERLAP = 80

# --- Embeddings ---
# Runs locally, free, no API key required.
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

# --- Retrieval ---
TOP_K = 4

# Chroma returns a *distance* (lower = more similar) for cosine space, not a
# similarity score. We convert distance -> similarity and compare against
# this threshold to decide whether we actually know the answer.
# Tuned empirically against sample_docs; see README for how to re-tune it
# against your own document set.
CONFIDENCE_THRESHOLD = 0.35

# --- LLM (Groq free tier) ---
GROQ_MODEL = "llama-3.1-8b-instant"
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
