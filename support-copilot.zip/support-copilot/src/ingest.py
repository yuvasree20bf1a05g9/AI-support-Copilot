"""
Ingestion pipeline: load documents (PDF or Markdown/text) -> split into
overlapping chunks -> embed -> store in a persistent Chroma vector DB.

Run directly to (re)build the vector store from sample_docs/:
    python src/ingest.py
"""

from pathlib import Path

from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma

from config import (
    SAMPLE_DOCS_DIR,
    VECTOR_DB_DIR,
    CHUNK_SIZE,
    CHUNK_OVERLAP,
    EMBEDDING_MODEL,
)


def load_documents(docs_dir: Path):
    """Load every .pdf, .md, and .txt file in docs_dir into LangChain Documents."""
    documents = []
    for path in sorted(docs_dir.glob("*")):
        if path.suffix.lower() == ".pdf":
            loader = PyPDFLoader(str(path))
        elif path.suffix.lower() in (".md", ".txt"):
            loader = TextLoader(str(path), encoding="utf-8")
        else:
            continue
        docs = loader.load()
        for d in docs:
            # Normalize the source name so citations shown to the user are clean
            d.metadata["source"] = path.name
        documents.extend(docs)
    return documents


def chunk_documents(documents):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n## ", "\n### ", "\n\n", "\n", ". ", " ", ""],
    )
    chunks = splitter.split_documents(documents)
    # Give each chunk a stable, human-readable id for citation display
    for i, chunk in enumerate(chunks):
        chunk.metadata["chunk_id"] = f"{chunk.metadata.get('source', 'doc')}#{i}"
    return chunks


def build_vector_store(chunks, persist_dir: Path):
    # normalize_embeddings=True + cosine space means the distance Chroma
    # returns is a true cosine distance in [0, 2], so `1 - distance` in
    # rag_pipeline.py is a mathematically valid similarity score.
    # (Chroma's default is raw L2 distance, which is NOT bounded to [0,1]
    # and would silently produce meaningless "confidence" numbers.)
    embeddings = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL,
        encode_kwargs={"normalize_embeddings": True},
    )
    persist_dir.mkdir(parents=True, exist_ok=True)
    vectordb = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=str(persist_dir),
        collection_metadata={"hnsw:space": "cosine"},
    )
    vectordb.persist()
    return vectordb


def run(docs_dir: Path = SAMPLE_DOCS_DIR, persist_dir: Path = VECTOR_DB_DIR):
    print(f"Loading documents from {docs_dir} ...")
    documents = load_documents(docs_dir)
    print(f"  loaded {len(documents)} document(s)")

    print("Splitting into chunks ...")
    chunks = chunk_documents(documents)
    print(f"  created {len(chunks)} chunk(s)")

    print("Embedding and writing to Chroma vector store ...")
    build_vector_store(chunks, persist_dir)
    print(f"Done. Vector store persisted at {persist_dir}")


if __name__ == "__main__":
    run()
