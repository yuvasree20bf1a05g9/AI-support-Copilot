"""
Core RAG pipeline: given a user question, retrieve relevant chunks from the
vector store, decide whether we're confident enough to answer, and if so,
generate a grounded answer with citations. If not, return an honest
"I don't have enough information" response so the UI can trigger a human
handoff instead of guessing.
"""

from dataclasses import dataclass, field
from typing import List

from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate

from config import (
    VECTOR_DB_DIR,
    EMBEDDING_MODEL,
    TOP_K,
    CONFIDENCE_THRESHOLD,
    GROQ_MODEL,
    GROQ_API_KEY,
)

SYSTEM_PROMPT = """You are a customer support copilot. Answer the user's question
using ONLY the context passages provided below. Do not use outside knowledge.

Rules:
- If the context fully answers the question, give a clear, direct answer.
- If the context only partially covers it, answer what you can and say what's missing.
- Never invent a policy detail, number, or rule that is not present in the context.
- Keep the answer concise: 2-4 sentences, written for a support agent to read
  and paste into a customer reply.

Context passages:
{context}

Question: {question}

Answer:"""


@dataclass
class Citation:
    source: str
    chunk_id: str
    snippet: str
    similarity: float


@dataclass
class CopilotResponse:
    answer: str
    citations: List[Citation] = field(default_factory=list)
    confident: bool = True
    top_similarity: float = 0.0


class SupportCopilot:
    def __init__(self):
        embeddings = HuggingFaceEmbeddings(
            model_name=EMBEDDING_MODEL,
            encode_kwargs={"normalize_embeddings": True},
        )
        self.vectordb = Chroma(
            persist_directory=str(VECTOR_DB_DIR),
            embedding_function=embeddings,
            collection_metadata={"hnsw:space": "cosine"},
        )
        self.llm = None
        if GROQ_API_KEY:
            self.llm = ChatGroq(model=GROQ_MODEL, api_key=GROQ_API_KEY, temperature=0.1)
        self.prompt = ChatPromptTemplate.from_template(SYSTEM_PROMPT)

    def retrieve(self, question: str, k: int = TOP_K):
        results = self.vectordb.similarity_search_with_score(question, k=k)
        citations = []
        for doc, distance in results:
            similarity = max(0.0, 1 - distance)
            citations.append(
                Citation(
                    source=doc.metadata.get("source", "unknown"),
                    chunk_id=doc.metadata.get("chunk_id", ""),
                    snippet=doc.page_content.strip(),
                    similarity=similarity,
                )
            )
        return citations

    def answer(self, question: str) -> CopilotResponse:
        citations = self.retrieve(question)
        top_similarity = citations[0].similarity if citations else 0.0

        # --- Confidence gate: this is the "don't hallucinate" safety valve ---
        if top_similarity < CONFIDENCE_THRESHOLD:
            return CopilotResponse(
                answer=(
                    "I don't have enough information in the knowledge base to "
                    "answer this confidently. Routing to a human agent."
                ),
                citations=citations,
                confident=False,
                top_similarity=top_similarity,
            )

        context = "\n\n---\n\n".join(
            f"[{c.chunk_id}]\n{c.snippet}" for c in citations
        )

        if self.llm is None:
            # No API key configured: still return the retrieved, cited context
            # so the pipeline is fully demonstrable without a paid/free-tier key.
            preview = citations[0].snippet[:280]
            return CopilotResponse(
                answer=(
                    "[No GROQ_API_KEY set — showing retrieved context instead of "
                    f"an LLM-generated answer]\n\n{preview}..."
                ),
                citations=citations,
                confident=True,
                top_similarity=top_similarity,
            )

        chain = self.prompt | self.llm
        result = chain.invoke({"context": context, "question": question})
        generated_answer = result.content

        return CopilotResponse(
            answer=generated_answer,
            citations=citations,
            confident=True,
            top_similarity=top_similarity,
        )
