"""
Support Copilot -- Streamlit chat UI.

Run with:
    streamlit run app.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

import streamlit as st
from config import VECTOR_DB_DIR, CONFIDENCE_THRESHOLD, GROQ_API_KEY

st.set_page_config(page_title="AI Support Copilot", page_icon="💬", layout="centered")

st.title("💬 AI Support Copilot")
st.caption(
    "RAG-based knowledge retrieval and response drafting for customer support. "
    "Answers are grounded in the uploaded policy documents and always cite their source."
)

# --- Warn early if the vector store hasn't been built yet ---
if not VECTOR_DB_DIR.exists():
    st.warning(
        "No vector store found yet. Run `python src/ingest.py` first to index "
        "the documents in `sample_docs/` (or your own uploaded documents)."
    )
    st.stop()

if not GROQ_API_KEY:
    st.info(
        "No `GROQ_API_KEY` set — the app will still retrieve and cite the right "
        "policy passages, but will show raw retrieved context instead of an "
        "LLM-composed answer. Add a free Groq API key to your `.env` file to "
        "enable full answer generation. See README for how to get one."
    )

from rag_pipeline import SupportCopilot  # noqa: E402  (import after path setup)


@st.cache_resource
def load_copilot():
    return SupportCopilot()


copilot = load_copilot()

if "messages" not in st.session_state:
    st.session_state.messages = []
if "escalated" not in st.session_state:
    st.session_state.escalated = False

# --- Render chat history ---
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("citations"):
            with st.expander("View sources"):
                for c in msg["citations"]:
                    st.markdown(
                        f"**{c.chunk_id}**  ·  similarity `{c.similarity:.2f}`\n\n"
                        f"> {c.snippet}"
                    )
        if msg.get("show_handoff"):
            if st.button("🙋 Escalate to human agent", key=f"handoff-{id(msg)}"):
                st.session_state.escalated = True

if st.session_state.escalated:
    st.success(
        "This conversation has been flagged for a human support associate. "
        "In a production system this would create a ticket and notify the "
        "on-duty agent queue."
    )

# --- Chat input ---
question = st.chat_input("Ask a customer-support question...")

if question:
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner("Retrieving relevant policy context..."):
            response = copilot.answer(question)

        st.markdown(response.answer)

        with st.expander(f"View sources (top similarity: {response.top_similarity:.2f})"):
            for c in response.citations:
                st.markdown(
                    f"**{c.chunk_id}**  ·  similarity `{c.similarity:.2f}`\n\n"
                    f"> {c.snippet}"
                )

        show_handoff = not response.confident
        if show_handoff:
            st.button("🙋 Escalate to human agent", key=f"handoff-live-{len(st.session_state.messages)}")

    st.session_state.messages.append(
        {
            "role": "assistant",
            "content": response.answer,
            "citations": response.citations,
            "show_handoff": show_handoff,
        }
    )

with st.sidebar:
    st.header("How this works")
    st.markdown(
        """
1. **Ingest** — support documents are chunked and embedded
2. **Retrieve** — top-matching chunks are pulled for each question
3. **Confidence gate** — if retrieval similarity is below
   `{:.2f}`, the copilot admits it doesn't know instead of guessing
4. **Generate** — an LLM drafts an answer grounded only in the
   retrieved context, with citations attached
5. **Escalate** — low-confidence or flagged answers get a
   one-click human handoff
        """.format(CONFIDENCE_THRESHOLD)
    )
    st.divider()
    if st.button("Clear conversation"):
        st.session_state.messages = []
        st.session_state.escalated = False
        st.rerun()
